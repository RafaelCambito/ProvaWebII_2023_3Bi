import { Footer, Footers } from "./styles";

export function Footer() {
    return (
        <Container>
            <Content>
                <div className="page-details">
                    <h1>Footer</h1>
                </div>
                <img src={logo} alt="" />
            </Content>
        </Container>
    );
}

