import { styled } from "styled-components";

export const Footer = styled.Footer`
    background: #43a602;
    display: flex;
    justify-content: center;
    height: 198px;
    align-items: center;
`;

export const Footers = styled.Footers `
    width: 100%;
    max-width: 1216px;
    display: flex;
    align-items: center;
    justify-content: space-between;

    .page-details {
        h1{
            color: #fff;
            font-size: 50px;
        }
    }
`